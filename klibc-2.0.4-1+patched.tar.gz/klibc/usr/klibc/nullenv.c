/*
 * nullenv.c
 */

#include <stddef.h>
#include "env.h"

char * const __null_environ[] = { NULL };
