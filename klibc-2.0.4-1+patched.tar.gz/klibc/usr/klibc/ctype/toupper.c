#include "ctypefunc.h"
CTYPEFUNC(toupper)
