#include "ctypefunc.h"
CTYPEFUNC(isalpha)
