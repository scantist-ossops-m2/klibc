#include "ctypefunc.h"
CTYPEFUNC(isalnum)
