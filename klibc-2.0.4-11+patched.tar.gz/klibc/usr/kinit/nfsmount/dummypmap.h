/*
 * Functions for the portmap spoofer
 */

#ifndef NFSMOUNT_DUMMYPORTMAP_H
#define NFSMOUNT_DUMMYPORTMAP_H

#include <unistd.h>
pid_t start_dummy_portmap(const char *file);

#endif /* NFSMOUNT_DUMMYPORTMAP_H */
