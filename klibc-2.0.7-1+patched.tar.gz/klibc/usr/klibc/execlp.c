/*
 * execlp.c
 */

#define NAME execlp
#define EXEC_P 1
#define EXEC_E 0
#include "exec_l.c"
