#ifndef _BITSIZE
#define _BITSIZE 32
#endif
