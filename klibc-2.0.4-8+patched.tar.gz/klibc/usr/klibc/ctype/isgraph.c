#include "ctypefunc.h"
CTYPEFUNC(isgraph)
