/*
 * arch/cris/include/klibc/archsignal.h
 *
 * Architecture-specific signal definitions
 *
 */

#ifndef _KLIBC_ARCHSIGNAL_H
#define _KLIBC_ARCHSIGNAL_H

#include <asm/signal.h>
/* No special stuff for this architecture */

#endif
